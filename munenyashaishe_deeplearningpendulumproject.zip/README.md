# Damped Pendulum Project

## Overview
This project models the motion of a damped pendulum using deep learning techniques. The ordinary differential equation (ODE) that describes the pendulum's motion is solved numerically, and the resulting data is used to train a neural network.

## Development Environment
- This project was developed using [Replit](https://replit.com/), an online IDE that allows for easy collaboration and quick prototyping without the need for local setup.

## Files
- `ode_py.py`: Contains the ODE function and numerical methods for solving the ODE.
- `data_generator.py`: Generates training and testing data from the numerical solutions.
- `train.py`: Implements the neural network model and training logic.
- `config.yaml`: Configuration file for hyperparameters.
- `README.md`: Overview and instructions for the project.

## Requirements
- Python 3.x
- JAX
- Flax
- Hydra
- Matplotlib

## How to Run
1. Clone the repository or download the files.
2. Install the required libraries using `pip install -r requirements.txt`.
3. Run the scripts in the appropriate order to generate data and train the model.

## Evaluation
The model's performance is evaluated using Mean Squared Error (MSE), and results are visualized using Matplotlib.
