import jax.numpy as jnp

def pendulum_ode(t, y, params=(0.3, 1.0, 1.0, 9.81)):
    """Define the ODE for the damped pendulum."""
    b, m, l, g = params
    theta, omega = y
    dtheta_dt = omega
    domega_dt = - (b / (m * l)) * omega - (g / l) * jnp.sin(theta)
    return jnp.array([dtheta_dt, domega_dt])

def euler_method(f, y0, t_span, dt, params):
    """Solve ODE using Euler's method."""
    t_values = jnp.arange(t_span[0], t_span[1], dt)
    y_values = jnp.zeros((len(t_values), len(y0)))
    y = y0
    for i, t in enumerate(t_values):
        y_values = y_values.at[i].set(y)
        y = y + f(t, y, params) * dt
    return t_values, y_values

def runge_kutta_method(f, y0, t_span, dt, params):
    """Solve ODE using the 4th-order Runge-Kutta method."""
    t_values = jnp.arange(t_span[0], t_span[1], dt)
    y_values = jnp.zeros((len(t_values), len(y0)))
    y = y0
    for i, t in enumerate(t_values):
        y_values = y_values.at[i].set(y)
        k1 = f(t, y, params)
        k2 = f(t + dt / 2, y + k1 * dt / 2, params)
        k3 = f(t + dt / 2, y + k2 * dt / 2, params)
        k4 = f(t + dt, y + k3 * dt, params)
        y = y + (k1 + 2 * k2 + 2 * k3 + k4) * dt / 6
    return t_values, y_values
